const uuidAPIkey = require('uuid-apikey');

console.log(uuidAPIkey.create());

