const puppy = "cute";
const puppy = "so cute"; // 'puppy' has already been declared