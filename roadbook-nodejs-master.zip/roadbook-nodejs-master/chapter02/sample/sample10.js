function add(a, b) {
    return a + b;
}

console.log(add(1, 4)); // 5