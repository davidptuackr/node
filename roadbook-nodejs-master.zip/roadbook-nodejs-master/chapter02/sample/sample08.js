const coffee = [];

coffee.push({ name: 'Americano' });
coffee.push({ name: "Latte" });

console.log(coffee); // [ { name: 'Americano' }, { name: 'Latte' } ]
console.log(coffee[0]); // { name: 'Americano' }
console.log(coffee.length); // 2