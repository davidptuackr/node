const puppy = "cute";
puppy = "so cute!!"; // TypeError: Assignment to constant variable.